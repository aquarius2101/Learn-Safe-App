/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package namuunPlanSafe;

/**
 *
 * @author Dell
 */
public interface ProgressTracker {
    String progressTrack(double list, double completed);

}
