/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stefanyActSafe;

/**
 *
 * @author stefanybento
 */
public class Locator extends ActSafe {
    private String county;
    private String nearestShelter;
    
    public Locator() {}

    public Locator(String county, String nearestShelter) {
        this.county = county;
        this.nearestShelter = nearestShelter;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public void setNearestShelter(String nearstShelter) {
        this.nearestShelter = nearstShelter;
    }

    public String getCounty() {
        return county;
    }

    public String getNearestShelter() {
        return nearestShelter;
    }
    
    public String findShelterByCounty(String county) {
        if (county == null || county.isEmpty()) {
            return "Please enter a county name.";
        }
        county = county.trim().toLowerCase();
        return switch (county) {
            case "dublin" -> """  
                            Dublin shelters:
                             
                            1) Dublin Community Shelter
                               15, O'Connell Street - Dublin 1
                             
                            2) Northside Emergency Accommodation
                               42, Gardiner Middle Street - Dublin 1
                            """;                                        
            case "cork" -> """  
                            Cork shelters:
                             
                            1) Cork Simon Emergency Shelter
                               8, Anderson's Quay - Cork
                             
                            2) Southside Support Hostel
                               21, Douglas Street - Cork
                            """;
            case "donegal" -> """  
                            Donnegal Support Centre
                            3, Harbour Road - Donegal Town
                            """;    
            case "galway" -> """  
                            Galway Safe Haven
                            12, Eyre Square - Galway City
                            """;
            case "limerick" -> """  
                            Novas Temporary Accommodation
                            5 Henry Street - Limerick
                            """;
            case "waterford" -> """  
                            Wateford City Homeless Hub
                            22, The Quay - Waterford
                            """;
            case "kilkenny" -> """  
                            Good Shepherd Centre
                            10, Patrick Street - Kilkenny
                            """;
            case "wicklow" -> """  
                            Wicklow Support Housing
                            7 Main Street - Wicklow Town
                            """;
            case "clare" -> """  
                            Clare Heaven Refuge
                            4, Abbey Street - Ennis, Co. Clare
                            """;
            case "kerry" -> """  
                            Kerry Homeless Assistance
                            9, High Street - Tralee, Co. Kerry
                            """;
            case "meath" -> """  
                            Meath Homeless Assistance
                            11, Railway Street - Navan, Co. Meath
                            """;
            case "laois" -> """  
                            Laois Emergency Housing
                            6, CHurch Street - Portlaoise, Co. Laois
                            """;    
            default -> "No shelter found in this county.";    
        };
        // The addresses are fictional
    }
    
    @Override
    public void printInfo() {
        super.printInfo();
        System.out.println("County: "+ county + "| Shelter " + nearestShelter);
    }
}
